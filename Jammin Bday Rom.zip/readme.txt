Jammin's B-day FE ROMHack v0.9

training session - 6 recruitable characters

secret shop added

collect all 5 secret keys for bonus =)

NOTE: recommended NOT to skip text via [START] or [B]!
	(game is v fragile like my heart so pls dont skip events or it will break :{ )

P.S. mGBA is known to have issues with FE Romhacks. if you have issues,
it is recommended to switch to a different emulator, such as VisualBoyAdvance.